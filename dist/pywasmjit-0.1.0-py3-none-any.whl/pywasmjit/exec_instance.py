from .callback_pool import CallbackPool


class ExecInstance:
    def __init__(self, callback_pool: CallbackPool, buf: bytes):
        pass

    def exec_function(self, func_name: str, *args):
        pass
